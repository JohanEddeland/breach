function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/throttle */
	this.urlHashMap["Autotrans_shift:84"] = "Autotrans_shift.c:411,422,539&Autotrans_shift.h:194";
	/* <Root>/brake */
	this.urlHashMap["Autotrans_shift:106"] = "Autotrans_shift.c:574&Autotrans_shift.h:195";
	/* <Root>/Scope */
	this.urlHashMap["Autotrans_shift:105"] = "Autotrans_shift.h:81";
	/* <Root>/Scope2 */
	this.urlHashMap["Autotrans_shift:107"] = "Autotrans_shift.h:85";
	/* <Root>/ShiftLogic */
	this.urlHashMap["Autotrans_shift:16"] = "Autotrans_shift.c:23,211,374,499,723&Autotrans_shift.h:72,87,88,89,90,91,92";
	/* <Root>/ThresholdCalculation */
	this.urlHashMap["Autotrans_shift:17"] = "Autotrans_shift.c:409,430";
	/* <Root>/speed */
	this.urlHashMap["Autotrans_shift:80"] = "Autotrans_shift.c:353&Autotrans_shift.h:200";
	/* <Root>/RPM */
	this.urlHashMap["Autotrans_shift:79"] = "Autotrans_shift.c:370&Autotrans_shift.h:201";
	/* <Root>/gear */
	this.urlHashMap["Autotrans_shift:104"] = "Autotrans_shift.c:501&Autotrans_shift.h:202";
	/* <S1>/EngineTorque */
	this.urlHashMap["Autotrans_shift:4"] = "Autotrans_shift.c:540&Autotrans_shift.h:155,160,165&Autotrans_shift_data.c:57,62,69";
	/* <S1>/Integrator */
	this.urlHashMap["Autotrans_shift:5"] = "Autotrans_shift.c:356,368,620,631,720&Autotrans_shift.h:66,98,104,110";
	/* <S1>/Sum */
	this.urlHashMap["Autotrans_shift:6"] = "Autotrans_shift.c:541";
	/* <S1>/engine + impeller
inertia */
	this.urlHashMap["Autotrans_shift:7"] = "Autotrans_shift.c:537&Autotrans_shift.h:69";
	/* <S2>:2 */
	this.urlHashMap["Autotrans_shift:16:2"] = "Autotrans_shift.c:214,389";
	/* <S2>:6 */
	this.urlHashMap["Autotrans_shift:16:6"] = "Autotrans_shift.c:217,253,394";
	/* <S2>:3 */
	this.urlHashMap["Autotrans_shift:16:3"] = "Autotrans_shift.c:228,266";
	/* <S2>:4 */
	this.urlHashMap["Autotrans_shift:16:4"] = "Autotrans_shift.c:222,239,274";
	/* <S2>:5 */
	this.urlHashMap["Autotrans_shift:16:5"] = "Autotrans_shift.c:233,245,260";
	/* <S2>:7 */
	this.urlHashMap["Autotrans_shift:16:7"] = "Autotrans_shift.c:400,413";
	/* <S2>:1 */
	this.urlHashMap["Autotrans_shift:16:1"] = "Autotrans_shift.c:433";
	/* <S2>:9 */
	this.urlHashMap["Autotrans_shift:16:9"] = "Autotrans_shift.c:457";
	/* <S2>:8 */
	this.urlHashMap["Autotrans_shift:16:8"] = "Autotrans_shift.c:475";
	/* <S2>:13 */
	this.urlHashMap["Autotrans_shift:16:13"] = "Autotrans_shift.c:390";
	/* <S2>:11 */
	this.urlHashMap["Autotrans_shift:16:11"] = "Autotrans_shift.c:242";
	/* <S2>:12 */
	this.urlHashMap["Autotrans_shift:16:12"] = "Autotrans_shift.c:219";
	/* <S2>:10 */
	this.urlHashMap["Autotrans_shift:16:10"] = "Autotrans_shift.c:263";
	/* <S2>:16 */
	this.urlHashMap["Autotrans_shift:16:16"] = "Autotrans_shift.c:250";
	/* <S2>:14 */
	this.urlHashMap["Autotrans_shift:16:14"] = "Autotrans_shift.c:230";
	/* <S2>:15 */
	this.urlHashMap["Autotrans_shift:16:15"] = "Autotrans_shift.c:271";
	/* <S2>:17 */
	this.urlHashMap["Autotrans_shift:16:17"] = "Autotrans_shift.c:401";
	/* <S2>:18 */
	this.urlHashMap["Autotrans_shift:16:18"] = "Autotrans_shift.c:459";
	/* <S2>:19 */
	this.urlHashMap["Autotrans_shift:16:19"] = "Autotrans_shift.c:466";
	/* <S2>:21 */
	this.urlHashMap["Autotrans_shift:16:21"] = "Autotrans_shift.c:449";
	/* <S2>:22 */
	this.urlHashMap["Autotrans_shift:16:22"] = "Autotrans_shift.c:437";
	/* <S2>:23 */
	this.urlHashMap["Autotrans_shift:16:23"] = "Autotrans_shift.c:478";
	/* <S2>:20 */
	this.urlHashMap["Autotrans_shift:16:20"] = "Autotrans_shift.c:489";
	/* <S2>:30 */
	this.urlHashMap["Autotrans_shift:16:30"] = "Autotrans_shift.c:438";
	/* <S2>:31 */
	this.urlHashMap["Autotrans_shift:16:31"] = "Autotrans_shift.c:479";
	/* <S2>:29 */
	this.urlHashMap["Autotrans_shift:16:29"] = "Autotrans_shift.c:414";
	/* <S3>/interp_down */
	this.urlHashMap["Autotrans_shift:21"] = "Autotrans_shift.c:410&Autotrans_shift.h:73,127,133,140&Autotrans_shift_data.c:26,32,39";
	/* <S3>/interp_up */
	this.urlHashMap["Autotrans_shift:22"] = "Autotrans_shift.c:421&Autotrans_shift.h:74,134,145,150&Autotrans_shift_data.c:33,45,50";
	/* <S5>/Final
Drive
Ratio1 */
	this.urlHashMap["Autotrans_shift:54"] = "Autotrans_shift.c:573";
	/* <S5>/FinalDriveRatio2 */
	this.urlHashMap["Autotrans_shift:55"] = "Autotrans_shift.c:516&Autotrans_shift.h:68";
	/* <S5>/LinearSpeed */
	this.urlHashMap["Autotrans_shift:56"] = "Autotrans_shift.c:347";
	/* <S5>/RoadLoad */
	this.urlHashMap["Autotrans_shift:57"] = "Autotrans_shift.c:572";
	/* <S5>/Sign */
	this.urlHashMap["Autotrans_shift:58"] = "Autotrans_shift.c:558,569";
	/* <S5>/SignedLoad */
	this.urlHashMap["Autotrans_shift:59"] = "Autotrans_shift.c:575";
	/* <S5>/Sum */
	this.urlHashMap["Autotrans_shift:60"] = "Autotrans_shift.c:576";
	/* <S5>/Sum1 */
	this.urlHashMap["Autotrans_shift:61"] = "Autotrans_shift.c:577";
	/* <S5>/Vehicle
Inertia */
	this.urlHashMap["Autotrans_shift:62"] = "Autotrans_shift.c:571&Autotrans_shift.h:71";
	/* <S5>/Wheel
Speed */
	this.urlHashMap["Autotrans_shift:63"] = "Autotrans_shift.c:348,517,617,717&Autotrans_shift.h:97,103,109";
	/* <S5>/mph */
	this.urlHashMap["Autotrans_shift:64"] = "Autotrans_shift.c:346&Autotrans_shift.h:65";
	/* <S6>/FactorK */
	this.urlHashMap["Autotrans_shift:32"] = "Autotrans_shift.c:528&Autotrans_shift.h:176,182&Autotrans_shift_data.c:89,97";
	/* <S6>/Impeller */
	this.urlHashMap["Autotrans_shift:33"] = "Autotrans_shift.c:534,538,550";
	/* <S6>/Quotient */
	this.urlHashMap["Autotrans_shift:34"] = "Autotrans_shift.c:527";
	/* <S6>/SpeedRatio */
	this.urlHashMap["Autotrans_shift:35"] = "Autotrans_shift.c:521";
	/* <S6>/TorqueRatio */
	this.urlHashMap["Autotrans_shift:36"] = "Autotrans_shift.c:551&Autotrans_shift.h:177,187&Autotrans_shift_data.c:90,108";
	/* <S6>/Turbine */
	this.urlHashMap["Autotrans_shift:37"] = "Autotrans_shift.c:552";
	/* <S7>/Look-Up
Table */
	this.urlHashMap["Autotrans_shift:44"] = "Autotrans_shift.c:511&Autotrans_shift.h:67,135,170&Autotrans_shift_data.c:34,83";
	/* <S7>/Product */
	this.urlHashMap["Autotrans_shift:45"] = "Autotrans_shift.c:549&Autotrans_shift.h:70";
	/* <S7>/Product1 */
	this.urlHashMap["Autotrans_shift:46"] = "Autotrans_shift.c:522";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "Autotrans_shift"};
	this.sidHashMap["Autotrans_shift"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "Autotrans_shift:1"};
	this.sidHashMap["Autotrans_shift:1"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "Autotrans_shift:16"};
	this.sidHashMap["Autotrans_shift:16"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "Autotrans_shift:17"};
	this.sidHashMap["Autotrans_shift:17"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "Autotrans_shift:25"};
	this.sidHashMap["Autotrans_shift:25"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "Autotrans_shift:51"};
	this.sidHashMap["Autotrans_shift:51"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<S6>"] = {sid: "Autotrans_shift:29"};
	this.sidHashMap["Autotrans_shift:29"] = {rtwname: "<S6>"};
	this.rtwnameHashMap["<S7>"] = {sid: "Autotrans_shift:40"};
	this.sidHashMap["Autotrans_shift:40"] = {rtwname: "<S7>"};
	this.rtwnameHashMap["<Root>/throttle"] = {sid: "Autotrans_shift:84"};
	this.sidHashMap["Autotrans_shift:84"] = {rtwname: "<Root>/throttle"};
	this.rtwnameHashMap["<Root>/brake"] = {sid: "Autotrans_shift:106"};
	this.sidHashMap["Autotrans_shift:106"] = {rtwname: "<Root>/brake"};
	this.rtwnameHashMap["<Root>/Engine"] = {sid: "Autotrans_shift:1"};
	this.sidHashMap["Autotrans_shift:1"] = {rtwname: "<Root>/Engine"};
	this.rtwnameHashMap["<Root>/Scope"] = {sid: "Autotrans_shift:105"};
	this.sidHashMap["Autotrans_shift:105"] = {rtwname: "<Root>/Scope"};
	this.rtwnameHashMap["<Root>/Scope2"] = {sid: "Autotrans_shift:107"};
	this.sidHashMap["Autotrans_shift:107"] = {rtwname: "<Root>/Scope2"};
	this.rtwnameHashMap["<Root>/ShiftLogic"] = {sid: "Autotrans_shift:16"};
	this.sidHashMap["Autotrans_shift:16"] = {rtwname: "<Root>/ShiftLogic"};
	this.rtwnameHashMap["<Root>/ThresholdCalculation"] = {sid: "Autotrans_shift:17"};
	this.sidHashMap["Autotrans_shift:17"] = {rtwname: "<Root>/ThresholdCalculation"};
	this.rtwnameHashMap["<Root>/Transmission"] = {sid: "Autotrans_shift:25"};
	this.sidHashMap["Autotrans_shift:25"] = {rtwname: "<Root>/Transmission"};
	this.rtwnameHashMap["<Root>/Vehicle"] = {sid: "Autotrans_shift:51"};
	this.sidHashMap["Autotrans_shift:51"] = {rtwname: "<Root>/Vehicle"};
	this.rtwnameHashMap["<Root>/speed"] = {sid: "Autotrans_shift:80"};
	this.sidHashMap["Autotrans_shift:80"] = {rtwname: "<Root>/speed"};
	this.rtwnameHashMap["<Root>/RPM"] = {sid: "Autotrans_shift:79"};
	this.sidHashMap["Autotrans_shift:79"] = {rtwname: "<Root>/RPM"};
	this.rtwnameHashMap["<Root>/gear"] = {sid: "Autotrans_shift:104"};
	this.sidHashMap["Autotrans_shift:104"] = {rtwname: "<Root>/gear"};
	this.rtwnameHashMap["<S1>/Ti"] = {sid: "Autotrans_shift:2"};
	this.sidHashMap["Autotrans_shift:2"] = {rtwname: "<S1>/Ti"};
	this.rtwnameHashMap["<S1>/Throttle"] = {sid: "Autotrans_shift:3"};
	this.sidHashMap["Autotrans_shift:3"] = {rtwname: "<S1>/Throttle"};
	this.rtwnameHashMap["<S1>/EngineTorque"] = {sid: "Autotrans_shift:4"};
	this.sidHashMap["Autotrans_shift:4"] = {rtwname: "<S1>/EngineTorque"};
	this.rtwnameHashMap["<S1>/Integrator"] = {sid: "Autotrans_shift:5"};
	this.sidHashMap["Autotrans_shift:5"] = {rtwname: "<S1>/Integrator"};
	this.rtwnameHashMap["<S1>/Sum"] = {sid: "Autotrans_shift:6"};
	this.sidHashMap["Autotrans_shift:6"] = {rtwname: "<S1>/Sum"};
	this.rtwnameHashMap["<S1>/engine + impeller inertia"] = {sid: "Autotrans_shift:7"};
	this.sidHashMap["Autotrans_shift:7"] = {rtwname: "<S1>/engine + impeller inertia"};
	this.rtwnameHashMap["<S1>/Ne"] = {sid: "Autotrans_shift:8"};
	this.sidHashMap["Autotrans_shift:8"] = {rtwname: "<S1>/Ne"};
	this.rtwnameHashMap["<S2>:2"] = {sid: "Autotrans_shift:16:2"};
	this.sidHashMap["Autotrans_shift:16:2"] = {rtwname: "<S2>:2"};
	this.rtwnameHashMap["<S2>:6"] = {sid: "Autotrans_shift:16:6"};
	this.sidHashMap["Autotrans_shift:16:6"] = {rtwname: "<S2>:6"};
	this.rtwnameHashMap["<S2>:3"] = {sid: "Autotrans_shift:16:3"};
	this.sidHashMap["Autotrans_shift:16:3"] = {rtwname: "<S2>:3"};
	this.rtwnameHashMap["<S2>:4"] = {sid: "Autotrans_shift:16:4"};
	this.sidHashMap["Autotrans_shift:16:4"] = {rtwname: "<S2>:4"};
	this.rtwnameHashMap["<S2>:5"] = {sid: "Autotrans_shift:16:5"};
	this.sidHashMap["Autotrans_shift:16:5"] = {rtwname: "<S2>:5"};
	this.rtwnameHashMap["<S2>:7"] = {sid: "Autotrans_shift:16:7"};
	this.sidHashMap["Autotrans_shift:16:7"] = {rtwname: "<S2>:7"};
	this.rtwnameHashMap["<S2>:1"] = {sid: "Autotrans_shift:16:1"};
	this.sidHashMap["Autotrans_shift:16:1"] = {rtwname: "<S2>:1"};
	this.rtwnameHashMap["<S2>:9"] = {sid: "Autotrans_shift:16:9"};
	this.sidHashMap["Autotrans_shift:16:9"] = {rtwname: "<S2>:9"};
	this.rtwnameHashMap["<S2>:8"] = {sid: "Autotrans_shift:16:8"};
	this.sidHashMap["Autotrans_shift:16:8"] = {rtwname: "<S2>:8"};
	this.rtwnameHashMap["<S2>:13"] = {sid: "Autotrans_shift:16:13"};
	this.sidHashMap["Autotrans_shift:16:13"] = {rtwname: "<S2>:13"};
	this.rtwnameHashMap["<S2>:11"] = {sid: "Autotrans_shift:16:11"};
	this.sidHashMap["Autotrans_shift:16:11"] = {rtwname: "<S2>:11"};
	this.rtwnameHashMap["<S2>:12"] = {sid: "Autotrans_shift:16:12"};
	this.sidHashMap["Autotrans_shift:16:12"] = {rtwname: "<S2>:12"};
	this.rtwnameHashMap["<S2>:10"] = {sid: "Autotrans_shift:16:10"};
	this.sidHashMap["Autotrans_shift:16:10"] = {rtwname: "<S2>:10"};
	this.rtwnameHashMap["<S2>:16"] = {sid: "Autotrans_shift:16:16"};
	this.sidHashMap["Autotrans_shift:16:16"] = {rtwname: "<S2>:16"};
	this.rtwnameHashMap["<S2>:14"] = {sid: "Autotrans_shift:16:14"};
	this.sidHashMap["Autotrans_shift:16:14"] = {rtwname: "<S2>:14"};
	this.rtwnameHashMap["<S2>:15"] = {sid: "Autotrans_shift:16:15"};
	this.sidHashMap["Autotrans_shift:16:15"] = {rtwname: "<S2>:15"};
	this.rtwnameHashMap["<S2>:17"] = {sid: "Autotrans_shift:16:17"};
	this.sidHashMap["Autotrans_shift:16:17"] = {rtwname: "<S2>:17"};
	this.rtwnameHashMap["<S2>:18"] = {sid: "Autotrans_shift:16:18"};
	this.sidHashMap["Autotrans_shift:16:18"] = {rtwname: "<S2>:18"};
	this.rtwnameHashMap["<S2>:19"] = {sid: "Autotrans_shift:16:19"};
	this.sidHashMap["Autotrans_shift:16:19"] = {rtwname: "<S2>:19"};
	this.rtwnameHashMap["<S2>:21"] = {sid: "Autotrans_shift:16:21"};
	this.sidHashMap["Autotrans_shift:16:21"] = {rtwname: "<S2>:21"};
	this.rtwnameHashMap["<S2>:22"] = {sid: "Autotrans_shift:16:22"};
	this.sidHashMap["Autotrans_shift:16:22"] = {rtwname: "<S2>:22"};
	this.rtwnameHashMap["<S2>:23"] = {sid: "Autotrans_shift:16:23"};
	this.sidHashMap["Autotrans_shift:16:23"] = {rtwname: "<S2>:23"};
	this.rtwnameHashMap["<S2>:20"] = {sid: "Autotrans_shift:16:20"};
	this.sidHashMap["Autotrans_shift:16:20"] = {rtwname: "<S2>:20"};
	this.rtwnameHashMap["<S2>:30"] = {sid: "Autotrans_shift:16:30"};
	this.sidHashMap["Autotrans_shift:16:30"] = {rtwname: "<S2>:30"};
	this.rtwnameHashMap["<S2>:31"] = {sid: "Autotrans_shift:16:31"};
	this.sidHashMap["Autotrans_shift:16:31"] = {rtwname: "<S2>:31"};
	this.rtwnameHashMap["<S2>:29"] = {sid: "Autotrans_shift:16:29"};
	this.sidHashMap["Autotrans_shift:16:29"] = {rtwname: "<S2>:29"};
	this.rtwnameHashMap["<S3>/gear"] = {sid: "Autotrans_shift:18"};
	this.sidHashMap["Autotrans_shift:18"] = {rtwname: "<S3>/gear"};
	this.rtwnameHashMap["<S3>/throttle"] = {sid: "Autotrans_shift:19"};
	this.sidHashMap["Autotrans_shift:19"] = {rtwname: "<S3>/throttle"};
	this.rtwnameHashMap["<S3>/run"] = {sid: "Autotrans_shift:20"};
	this.sidHashMap["Autotrans_shift:20"] = {rtwname: "<S3>/run"};
	this.rtwnameHashMap["<S3>/interp_down"] = {sid: "Autotrans_shift:21"};
	this.sidHashMap["Autotrans_shift:21"] = {rtwname: "<S3>/interp_down"};
	this.rtwnameHashMap["<S3>/interp_up"] = {sid: "Autotrans_shift:22"};
	this.sidHashMap["Autotrans_shift:22"] = {rtwname: "<S3>/interp_up"};
	this.rtwnameHashMap["<S3>/down_th"] = {sid: "Autotrans_shift:23"};
	this.sidHashMap["Autotrans_shift:23"] = {rtwname: "<S3>/down_th"};
	this.rtwnameHashMap["<S3>/up_th"] = {sid: "Autotrans_shift:24"};
	this.sidHashMap["Autotrans_shift:24"] = {rtwname: "<S3>/up_th"};
	this.rtwnameHashMap["<S4>/Ne"] = {sid: "Autotrans_shift:26"};
	this.sidHashMap["Autotrans_shift:26"] = {rtwname: "<S4>/Ne"};
	this.rtwnameHashMap["<S4>/gear"] = {sid: "Autotrans_shift:27"};
	this.sidHashMap["Autotrans_shift:27"] = {rtwname: "<S4>/gear"};
	this.rtwnameHashMap["<S4>/Nout"] = {sid: "Autotrans_shift:28"};
	this.sidHashMap["Autotrans_shift:28"] = {rtwname: "<S4>/Nout"};
	this.rtwnameHashMap["<S4>/TorqueConverter"] = {sid: "Autotrans_shift:29"};
	this.sidHashMap["Autotrans_shift:29"] = {rtwname: "<S4>/TorqueConverter"};
	this.rtwnameHashMap["<S4>/TransmissionRatio"] = {sid: "Autotrans_shift:40"};
	this.sidHashMap["Autotrans_shift:40"] = {rtwname: "<S4>/TransmissionRatio"};
	this.rtwnameHashMap["<S4>/Ti"] = {sid: "Autotrans_shift:49"};
	this.sidHashMap["Autotrans_shift:49"] = {rtwname: "<S4>/Ti"};
	this.rtwnameHashMap["<S4>/Tout"] = {sid: "Autotrans_shift:50"};
	this.sidHashMap["Autotrans_shift:50"] = {rtwname: "<S4>/Tout"};
	this.rtwnameHashMap["<S5>/OutputTorque"] = {sid: "Autotrans_shift:52"};
	this.sidHashMap["Autotrans_shift:52"] = {rtwname: "<S5>/OutputTorque"};
	this.rtwnameHashMap["<S5>/BrakeTorque"] = {sid: "Autotrans_shift:53"};
	this.sidHashMap["Autotrans_shift:53"] = {rtwname: "<S5>/BrakeTorque"};
	this.rtwnameHashMap["<S5>/Final Drive Ratio1"] = {sid: "Autotrans_shift:54"};
	this.sidHashMap["Autotrans_shift:54"] = {rtwname: "<S5>/Final Drive Ratio1"};
	this.rtwnameHashMap["<S5>/FinalDriveRatio2"] = {sid: "Autotrans_shift:55"};
	this.sidHashMap["Autotrans_shift:55"] = {rtwname: "<S5>/FinalDriveRatio2"};
	this.rtwnameHashMap["<S5>/LinearSpeed"] = {sid: "Autotrans_shift:56"};
	this.sidHashMap["Autotrans_shift:56"] = {rtwname: "<S5>/LinearSpeed"};
	this.rtwnameHashMap["<S5>/RoadLoad"] = {sid: "Autotrans_shift:57"};
	this.sidHashMap["Autotrans_shift:57"] = {rtwname: "<S5>/RoadLoad"};
	this.rtwnameHashMap["<S5>/Sign"] = {sid: "Autotrans_shift:58"};
	this.sidHashMap["Autotrans_shift:58"] = {rtwname: "<S5>/Sign"};
	this.rtwnameHashMap["<S5>/SignedLoad"] = {sid: "Autotrans_shift:59"};
	this.sidHashMap["Autotrans_shift:59"] = {rtwname: "<S5>/SignedLoad"};
	this.rtwnameHashMap["<S5>/Sum"] = {sid: "Autotrans_shift:60"};
	this.sidHashMap["Autotrans_shift:60"] = {rtwname: "<S5>/Sum"};
	this.rtwnameHashMap["<S5>/Sum1"] = {sid: "Autotrans_shift:61"};
	this.sidHashMap["Autotrans_shift:61"] = {rtwname: "<S5>/Sum1"};
	this.rtwnameHashMap["<S5>/Vehicle Inertia"] = {sid: "Autotrans_shift:62"};
	this.sidHashMap["Autotrans_shift:62"] = {rtwname: "<S5>/Vehicle Inertia"};
	this.rtwnameHashMap["<S5>/Wheel Speed"] = {sid: "Autotrans_shift:63"};
	this.sidHashMap["Autotrans_shift:63"] = {rtwname: "<S5>/Wheel Speed"};
	this.rtwnameHashMap["<S5>/mph"] = {sid: "Autotrans_shift:64"};
	this.sidHashMap["Autotrans_shift:64"] = {rtwname: "<S5>/mph"};
	this.rtwnameHashMap["<S5>/VehicleSpeed"] = {sid: "Autotrans_shift:65"};
	this.sidHashMap["Autotrans_shift:65"] = {rtwname: "<S5>/VehicleSpeed"};
	this.rtwnameHashMap["<S5>/TransmissionRPM"] = {sid: "Autotrans_shift:66"};
	this.sidHashMap["Autotrans_shift:66"] = {rtwname: "<S5>/TransmissionRPM"};
	this.rtwnameHashMap["<S6>/Ne"] = {sid: "Autotrans_shift:30"};
	this.sidHashMap["Autotrans_shift:30"] = {rtwname: "<S6>/Ne"};
	this.rtwnameHashMap["<S6>/Nin"] = {sid: "Autotrans_shift:31"};
	this.sidHashMap["Autotrans_shift:31"] = {rtwname: "<S6>/Nin"};
	this.rtwnameHashMap["<S6>/FactorK"] = {sid: "Autotrans_shift:32"};
	this.sidHashMap["Autotrans_shift:32"] = {rtwname: "<S6>/FactorK"};
	this.rtwnameHashMap["<S6>/Impeller"] = {sid: "Autotrans_shift:33"};
	this.sidHashMap["Autotrans_shift:33"] = {rtwname: "<S6>/Impeller"};
	this.rtwnameHashMap["<S6>/Quotient"] = {sid: "Autotrans_shift:34"};
	this.sidHashMap["Autotrans_shift:34"] = {rtwname: "<S6>/Quotient"};
	this.rtwnameHashMap["<S6>/SpeedRatio"] = {sid: "Autotrans_shift:35"};
	this.sidHashMap["Autotrans_shift:35"] = {rtwname: "<S6>/SpeedRatio"};
	this.rtwnameHashMap["<S6>/TorqueRatio"] = {sid: "Autotrans_shift:36"};
	this.sidHashMap["Autotrans_shift:36"] = {rtwname: "<S6>/TorqueRatio"};
	this.rtwnameHashMap["<S6>/Turbine"] = {sid: "Autotrans_shift:37"};
	this.sidHashMap["Autotrans_shift:37"] = {rtwname: "<S6>/Turbine"};
	this.rtwnameHashMap["<S6>/Ti"] = {sid: "Autotrans_shift:38"};
	this.sidHashMap["Autotrans_shift:38"] = {rtwname: "<S6>/Ti"};
	this.rtwnameHashMap["<S6>/Tt"] = {sid: "Autotrans_shift:39"};
	this.sidHashMap["Autotrans_shift:39"] = {rtwname: "<S6>/Tt"};
	this.rtwnameHashMap["<S7>/Tin"] = {sid: "Autotrans_shift:41"};
	this.sidHashMap["Autotrans_shift:41"] = {rtwname: "<S7>/Tin"};
	this.rtwnameHashMap["<S7>/gear"] = {sid: "Autotrans_shift:42"};
	this.sidHashMap["Autotrans_shift:42"] = {rtwname: "<S7>/gear"};
	this.rtwnameHashMap["<S7>/Nout"] = {sid: "Autotrans_shift:43"};
	this.sidHashMap["Autotrans_shift:43"] = {rtwname: "<S7>/Nout"};
	this.rtwnameHashMap["<S7>/Look-Up Table"] = {sid: "Autotrans_shift:44"};
	this.sidHashMap["Autotrans_shift:44"] = {rtwname: "<S7>/Look-Up Table"};
	this.rtwnameHashMap["<S7>/Product"] = {sid: "Autotrans_shift:45"};
	this.sidHashMap["Autotrans_shift:45"] = {rtwname: "<S7>/Product"};
	this.rtwnameHashMap["<S7>/Product1"] = {sid: "Autotrans_shift:46"};
	this.sidHashMap["Autotrans_shift:46"] = {rtwname: "<S7>/Product1"};
	this.rtwnameHashMap["<S7>/Tout"] = {sid: "Autotrans_shift:47"};
	this.sidHashMap["Autotrans_shift:47"] = {rtwname: "<S7>/Tout"};
	this.rtwnameHashMap["<S7>/Nin"] = {sid: "Autotrans_shift:48"};
	this.sidHashMap["Autotrans_shift:48"] = {rtwname: "<S7>/Nin"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
