function st = get_st(phi)
%GET_ST gets the field st of a formula
% 
% Synopsis: st = get_st(phi)
%

st = phi.st;
  
end
