t1 = [0 1 2 ] 
y1 = [1  2 3]
t2 = [0 1.3 2]
y2 = [2 1 4]

[to yo] = RobustAnd(t1,y1,t2,y2)
