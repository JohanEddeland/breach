/*
 * rt_look2d_normal.h
 *
 * Code generation for model "brdemo_autotrans".
 *
 * Model version              : 1.277
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Tue Nov 14 14:05:09 2017
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rt_look2d_normal_h_
#define RTW_HEADER_rt_look2d_normal_h_
#include "rtwtypes.h"
#include "rt_look.h"

extern real_T rt_Lookup2D_Normal (const real_T *xVals, const int_T numX,
  const real_T *yVals, const int_T numY,
  const real_T *zVals,
  const real_T x, const real_T y);

#endif                                 /* RTW_HEADER_rt_look2d_normal_h_ */
