function id = get_id(phi)
%GET_ID provides the id of the formula phi
% 
% Synopsis: id = get_id(phi)
%

id=phi.id;

end
