classdef BreachOperator
    enumeration
        NOT, OR, AND, IMPLIES, IFF, XOR, EV, ALW;
    end
end