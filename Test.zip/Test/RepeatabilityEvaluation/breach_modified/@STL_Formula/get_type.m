function type = get_type(phi)
 type = phi.type;
end