function res = snobfit_wrapper(x, brProblem)

res = brProblem.objective(x);

end