classdef time_shift_signal_gen
 

methods
    function this= time_shift_signal_gen(sg)
    
        this.sg.copy();
        
    
    end
    
    
end

end